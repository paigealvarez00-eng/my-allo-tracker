
"use strict";

function getList() {
    return document.getElementById("list").value
        .split(",")
        .map(Number);
}

function updateList(arr) {
    document.getElementById("list").value = arr.join(", ");
}

function showOutput(message) {
    document.getElementById("output").textContent = message;
}

// Search for a value
function searchElement(arr, target) {
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] === target) {
            return i;
        }
    }
    return -1;
}

// Insert a value at a position
function insertAt(arr, pos, value) {
    arr.splice(pos, 0, value);
}

// Delete a value at a position
function deleteAt(arr, pos) {
    arr.splice(pos, 1);
}

// Extract a portion of the array
function sliceArray(arr, start, end) {
    return arr.slice(start, end);
}

// Search button
function handleSearch() {
    const arr = getList();
    const target = Number(
        document.getElementById("searchValue").value
    );

    const index = searchElement(arr, target);

    if (index !== -1) {
        showOutput(
            `Found ${target} at index ${index}.\n\n` +
            `Current list: [${arr.join(", ")}]`
        );
    } else {
        showOutput(
            `${target} not found.\n\n` +
            `Current list: [${arr.join(", ")}]`
        );
    }
}

// Insert button
function handleInsert() {
    const arr = getList();
    const value = Number(
        document.getElementById("insertValue").value
    );
    const pos = Number(
        document.getElementById("insertIndex").value
    );

    if (!Number.isInteger(pos) || pos < 0 || pos > arr.length) {
        showOutput("Invalid insertion index.");
        return;
    }

    insertAt(arr, pos, value);
    updateList(arr);

    showOutput(
        `Inserted ${value} at index ${pos}.\n\n` +
        `Current list: [${arr.join(", ")}]`
    );
}

// Delete button
function handleDelete() {
    const arr = getList();
    const pos = Number(
        document.getElementById("deleteIndex").value
    );

    if (!Number.isInteger(pos) || pos < 0 || pos >= arr.length) {
        showOutput("Invalid deletion index.");
        return;
    }

    deleteAt(arr, pos);
    updateList(arr);

    showOutput(
        `Deleted element at index ${pos}.\n\n` +
        `Current list: [${arr.join(", ")}]`
    );
}

// Slice button
function handleSlice() {
    const arr = getList();
    const start = Number(
        document.getElementById("sliceStart").value
    );
    const end = Number(
        document.getElementById("sliceEnd").value
    );

    if (
        !Number.isInteger(start) ||
        !Number.isInteger(end) ||
        start < 0 ||
        end < start ||
        end > arr.length
    ) {
        showOutput("Invalid slice range.");
        return;
    }

    const result = sliceArray(arr, start, end);

    showOutput(
        `Slice [${start}:${end}] = [${result.join(", ")}]\n\n` +
        `Current list: [${arr.join(", ")}]`
    );
}
